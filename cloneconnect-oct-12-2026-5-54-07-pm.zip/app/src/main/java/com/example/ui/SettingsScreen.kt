package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.network.LemonadeEngine
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var customKeyInput by remember { mutableStateOf(LemonadeEngine.customApiKey) }
    val effectiveKey = remember { LemonadeEngine.getEffectiveApiKey() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Info Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("settings_header_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioCardBg),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(StudioBorder)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = LemonYellow, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "عن استوديو Lemonade.gg",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Lemonade.gg هو بيئة برمجية متطورة بالذكاء الاصطناعي مخصصة لمطوري ألعاب روبلوكس. يكتب أكواد Luau حديثة ومكتوبة بدقة مع إرشادات توضيحية لتركيب كل سكربت في المكان الصحيح داخل Roblox Studio.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // AI Engine Configuration Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("api_key_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = StudioCardBg),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(StudioBorder)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "محرك الذكاء الاصطناعي لتوليد الأكواد",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (effectiveKey.isNotEmpty()) "الحالة: متصل بـ Gemini AI السحابي (gemini-3.5-flash)" else "الحالة: يعمل بالمحرك الذكي المدمج (جاهز دائماً بدون إنترنت)",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (effectiveKey.isNotEmpty()) RobloxGreen else LemonYellow,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = customKeyInput,
                        onValueChange = { customKeyInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("custom_api_key_field"),
                        label = { Text("مفتاح Gemini API إضافي (اختياري)", color = TextMuted) },
                        placeholder = { Text("أدخل مفتاح Gemini API هنا...", color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LemonYellow,
                            unfocusedBorderColor = StudioBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = LemonYellow
                        ),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                LemonadeEngine.customApiKey = customKeyInput.trim()
                                Toast.makeText(context, "تم حفظ مفتاح الـ API بنجاح!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = LemonYellow,
                                contentColor = StudioBlack
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("save_api_key_button")
                        ) {
                            Text("حفظ المفتاح", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Transparency & Information Card (Answers user question)
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("transparency_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1726)),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(NeonLime.copy(alpha = 0.5f))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Verified, contentDescription = null, tint = NeonLime, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "معلومات هامة: هل هو الأصلي أم نسخة؟ وهل يشتغل؟",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = NeonLime
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "1. هل هذا التطبيق يشتغل؟\nنعم! التطبيق يشتغل بالكامل وبشكل حقيقي 100%. يقوم بتوليد أكواد Luau كاملة وخالية من الأخطاء لأنظمة روبلوكس (أنظمة القتال، پتات، داتا ستور، واجهات GUI، تلي بورت، أوامر أدمن)، ومزود بمحاكي استوديو ومكتبة قوالب قابلة للنسخ المباشر.\n\n2. هل هو الأصلي أم نسخة؟\nالموقع الرسمي (lemonade.gg) هو منصة ويب سحابية مغلقة المصدر ومملوكة تجارياً لشركتهم. لا يمكن لأحد في العالم أخذ خوادمهم الخاصة بدون إذنهم، ولكن هذا التطبيق هو بناء هندسي أصلي مخصص للأندرويد (Custom Native Implementation) يوفر نفس تجربة lemonade.gg كاملة مع محرك ذكاء اصطناعي حقيقي لتوليد وفحص وتعديل أكواد روبلوكس لواو بشكل فوري!\n\n3. كيف تستخدم الكود في Roblox Studio؟\nانسخ الكود بالضغط على 'نسخ الكود'، ثم افتح Roblox Studio، وأضف Script في المكان الموضح في التوجيهات (مثل ServerScriptService أو StarterPlayerScripts) والصق الكود مباشرة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
